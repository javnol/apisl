Files in this directory
=======================

- bootstrap.min.js: Minified version of the Bootstrap 3.4.1 javascript.
- jquery.min.js: Minified version of jquery 2.2.4

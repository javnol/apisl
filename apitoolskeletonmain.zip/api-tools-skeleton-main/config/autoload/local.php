<?php
return [
    'statuslib' => [
        'array_mapper_path' => 'data/statuslib.php',
    ],
    'api-tools-mvc-auth' => [
        'authentication' => [
            'adapters' => [
                'status' => [
                    'adapter' => \Laminas\ApiTools\MvcAuth\Authentication\HttpAdapter::class,
                    'options' => [
                        'accept_schemes' => [
                            0 => 'basic',
                        ],
                        'realm' => 'Realm',
                        'htpasswd' => 'data/htpasswd',
                    ],
                ],
            ],
        ],
    ],
];

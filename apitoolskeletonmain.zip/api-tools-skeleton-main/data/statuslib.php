<?php
return array(
    'ba22ac26-4794-4bc6-8bd9-2ca95b6ed474' => array(
        'message' => 'First post!',
        'user' => 'mwop',
        'id' => 'ba22ac26-4794-4bc6-8bd9-2ca95b6ed474',
        'timestamp' => 1627749778,
    ),
);

<?php
namespace Project\V1\Rest\Users;

use ArrayObject;

class UsersEntity extends ArrayObject
{
}

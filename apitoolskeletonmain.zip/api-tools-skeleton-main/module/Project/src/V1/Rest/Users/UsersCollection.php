<?php
namespace Project\V1\Rest\Users;

use Laminas\Paginator\Paginator;

class UsersCollection extends Paginator
{
}

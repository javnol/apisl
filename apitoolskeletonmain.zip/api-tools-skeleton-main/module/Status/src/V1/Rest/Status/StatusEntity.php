<?php
namespace Status\V1\Rest\Status;

class StatusEntity
{
}

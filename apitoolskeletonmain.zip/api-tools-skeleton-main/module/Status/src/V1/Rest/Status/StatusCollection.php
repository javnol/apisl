<?php
namespace Status\V1\Rest\Status;

use Laminas\Paginator\Paginator;

class StatusCollection extends Paginator
{
}

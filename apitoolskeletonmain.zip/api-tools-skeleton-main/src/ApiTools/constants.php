<?php

declare(strict_types=1);

namespace ApiTools;

const VERSION = '1.6.0dev';
